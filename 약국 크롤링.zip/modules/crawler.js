
import puppeteer from 'puppeteer-core'
import os from 'os'
import fs, { fdatasync } from 'fs'

const macUrl = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
const whidowsUrl = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
const currentOs = os.type()
const launchConfig = {
    headless: false,
    defaultViewport: null,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-notifications', '--disable-extensions'],
    executablePath: currentOs == 'Darwin' ? macUrl : whidowsUrl
}

//전역변수 global
const pageSelector = "body > table:nth-child(2) > tbody > tr > td:nth-child(1) > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(5) > td > table:nth-child(5) > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(3)"
let browser = null
let page = null
let pageLength = 0
let finalData = []
let sido = null
let sigungu = null


//실행, unit
const launch = async function ( arg1, arg2 ) { //const 상수(정해진값)
    sido = arg1
    sigungu = arg2
    browser = await puppeteer.launch(launchConfig); //브라우저 실행, async는 프로미스로 await를 통해 return하게 해줌(세트!)
    const pages = await browser.pages()
    page = pages[0] //새로운 탭
    //await page.newPage();//페이지 이동
}

const goto = async function (url) { //페이지 이동
    return await page.goto(url)
}

const checkPopup = async function () {
    const pages = await browser.pages()
    await pages.at(-1).close() // at이 length에 제일 마지막을 찾아줌  
}

const evalCode = async function () {
    await page.evaluate(function (sido) {
        document.querySelector(`#continents > li.${sido} > a`).click() //querySelctor 단일 요소만 선택
    }, sido)
}

const evalCity = async function () {
    //해당 엘리먼트를 찾을때까지 기다림
    await page.waitForSelector(`#container #continents > li.${sigungu} > a`) //이동하자마자 페이지가 바로 있는게 아니라 그려지는 시간이 있어야 작동할 수 있음 / 페이지가 이동이 되고 구동이 되어있을때 사용한다. 
    await page.evaluate(function (sigungu) {
        document.querySelector(`#container #continents > li.${sigungu} > a`).click() //지도가 두개라 안잡히는 경우 #container  #continents를 적어서 셀렉터를 설정해줌 
    }, sigungu)
}

const alertClose = async function () {
    await page.on('dialog', async function (dialog) { //page. 은 이름이 정해져있음 (이름이 아님), on은 이벤트 함수로 있을시에 작동하고 없으면 작동 안함
        await dialog.accept() //창이 아니라 alert이니까 그냥 accept만 하면 됨 
    })
}

const getPageLength = async function () {
    await page.waitForSelector(pageSelector)

    pageLength = await page.evaluate(function (pageSelector) {
        const result = document.querySelector(pageSelector).children.length
        return result
    }, pageSelector)

} //다시보기

const getData = async function () {

    //페이지 수 만큼 반복
    for (let i = 1; i <= pageLength; i++) {

        await page.waitForSelector(pageSelector)
        //TODO

        const inforArr = await page.evaluate(function (i, sido,sigungu) {

            //브라우저에서 돌아가는 코드 
            var trArr = document.querySelectorAll("#printZone > table:nth-child(2) > tbody tr")
            var returnData = []

            for (var i = 0; i < trArr.length; i++) {
                var currentTr = trArr[i]

                var name = currentTr.querySelector('td')?.innerText.replaceAll('\n', '').replaceAll('\t', '')
                var address = currentTr.querySelectorAll('td')[2]?.innerText.replaceAll('\n', '').replaceAll('\t', '')
                var tel = currentTr.querySelectorAll('td')[3]?.innerText.replaceAll('\n', '').replaceAll('\t', '')
                var open = currentTr.querySelectorAll('td')[4]?.innerText.replaceAll('\n', '').replaceAll('\t', '')

                var jsonData = { name, address, tel, open, sido, sigungu }

                if (jsonData.address != undefined) {
                    returnData.push(jsonData)
                }
            } //end for

            return returnData
        }, i, sido, sigungu)//end eval

        finalData = finalData.concat(inforArr) //concat은 array안에 있는 내장함수 
        console.log(finalData.length)

        if (pageLength != i) {
            //다음페이지 이동 
        await page.evaluate(function (i, pageSelector) {
                //eval
                document.querySelector(pageSelector).children[i].click() //children을 i로 입력해주면서 돌게 해야한다. 만약 1로 고정하면 1p만 뜸
        }, i, pageSelector)//end eval
        
            await page.waitForSelector('#printZone')
        }
    }//end for
    ////evaluate는 콘솔에 이 코드가 입력이 된다는 것, function안에 i를 넣고 뒤에 i를 넣는 공식은 외우기 / await page.evaluate(함수, i, pageSelector) 

    browser.close()
}// end getData

const writeFile = async function () {
    const stringData = JSON.stringify(finalData) //문자열로 변환

    const exist = fs.existsSync(`./json/${sido}`)

    if(!exist) {
        fs.mkdir(`./json/${sido}`, {recursive: true}, function(err){
            console.log(err)
        }) //파일이 없으면 해당 파일을 생성
    }

    const filePath = `./json/${sido}/${sigungu}.json`
    
    await fs.writeFileSync(filePath, stringData)
}

export {
    launch,
    goto,
    alertClose,
    checkPopup,
    evalCode,
    evalCity,
    getPageLength,
    getData,
    writeFile
}

