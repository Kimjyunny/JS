
// setTimeout(function(){
//     console.log('a')
// }, 3000) //3초 뒤에 a 함수가 실행이 된다 


// setTimeout(function(){
//     console.log('b')
// }, 1000) ///1초뒤에 b함수가 실행이 된다 


//콜백함수

// function cofeeMachine (type, callback) {
//     setTimeout(function(){
//         console.log(type, ':done')
//         callback()
//     }, 2000) //커피머신이 실행되는때 시간은 2초뒤
// }

// cofeeMachine('A', function(){
//     cofeeMachine('B', function(){ 
//         cofeeMachine('C', function(){
//             cofeeMachine('D', function(){

//             })
//         })
//     }) //콜백이 늘어날수록 가독성이 안좋아짐 

// }) //A라는 타입의 원두를 넣고

//대안방안 : Promise
// function asyncTask (args) {
//     const promise = new Promise(function(resolve, reject){
//         setTimeout(function(){
//             console.log(args)
//             resolve()
//         }, 1000)
//     })
//     return promise
// }
// asyncTask('task 1')
// .then(function(){
//     return asyncTask('task 2')
// })
// .then(function(){
//     return asyncTask('task 3')
// }) //그래도 코드가 길다

//대안방안 : async await
// await asyncTask('task A')
// await asyncTask('task B')
// await asyncTask('task C')
// await asyncTask('task 1')



var trArr = document.querySelectorAll("#printZone > table:nth-child(2) > tbody tr") // tr(table row), td(table data)
//id는 하나 밖에 없음 여기서 id는 printZone, 여기에 table이 두개가 있는데 2번 테이블만 뽑을꺼임 부등호가 있으면 바로 아래(tbody) 하나만 뽑고, tr은 부등호가 없으니 전체를 뽑는다. querySelectAll이니까 전체의 tr이 나오고 querySelect를 한다면 하나의 tr만 나온다. 

//nth-child는 선택자로 1부터 시작한다

var returnData = [] //다수 모색

for (var i = 0; i < trArr.length; i++) {
    var currentTr = trArr[i]

    var name = currentTr.querySelectorAll('td')?.innerText //?.을 하게 되면 undefined    원래는 .innertext인데 그 에러를 피하기 위해 ?를 붙이는거임//optional chain검색 / td를 보면 
    var address = currentTr.querySelectorAll('td')[2]?.innerText
    var tel = currentTr.querySelectorAll('td')[3]?.innerText
    var open = currentTr.querySelectorAll('td')[4]?.innerText
//document.querySelector("#printZone > table:nth-child(2) > tbody tr").querySelectAll("td") 를 입력하면 td에 대한 번호가 나온다 


    var jsonData = {
        name,
        address,
        tel,
        open
    }

    if(jsonData.address != undefined) {
        returnData.push(jsonData)
    }
}

