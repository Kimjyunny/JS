import {launch, goto, alertClose, checkPopup, evalCode, evalCity, getPageLength, getData, writeFile } from './modules/crawler.js' //./는하면 현재 레벨에 있는 경로를 찾고 그 모듈스에 있는 크롤러를 불러왔음

async function main() {
  //브라우저 실행
 await launch('jeju', 'jeju') //여기에 시도군을 바꾸면 json 폴더에 입력이 됨 

//페이지 이동 
 await goto('https://www.pharm114.or.kr/main.asp') //promise니깍 await 올려줘야함 

 await checkPopup()

 await evalCode()
 
 await evalCity()

 await alertClose()

 await getPageLength()

 await getData()

 await writeFile()
 
 process.exit(1)
}


main()