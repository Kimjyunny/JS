
import puppeteer from 'puppeteer-core'
import os from 'os'
import fs from 'fs'

const macUrl = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
const whidowsUrl = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
const currentOs = os.type()
const launchConfig = {
    headless: false,
    defaultViewport: null,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-notifications', '--disable-extensions'],
    executablePath: currentOs == 'Darwin' ? macUrl : whidowsUrl
}

//전역변수 global
const pageSelector = "body > table:nth-child(2) > tbody > tr > td:nth-child(1) > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(5) > td > table:nth-child(5) > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(3)"
let browser = null
let page = null
let pageLength = 0 


//실행, unit
const launch = async function () { //const 상수(정해진값)
    browser = await puppeteer.launch(launchConfig); //브라우저 실행, async는 프로미스로 await를 통해 return하게 해줌(세트!)
    const pages = await browser.pages()
    page = pages[0] //새로운 탭
    //await page.newPage();//페이지 이동
}

const goto = async function (url) { //페이지 이동
    return await page.goto(url)
}

const checkPopup = async function () {
    const pages = await browser.pages()
    await pages.at(-1).close() // at이 length에 제일 마지막을 찾아줌  
}

const evalCode = async function (name) {
    await page.evaluate(function (name) {
        document.querySelector(`#continents > li.${name} > a`).click() //querySelctor 단일 요소만 선택
    }, name)
}

const evalCity = async function (sigungu) {
    //해당 엘리먼트를 찾을때까지 기다림
    await page.waitForSelector(`#continents > li.${sigungu} > a`) //이동하자마자 페이지가 바로 있는게 아니라 그려지는 시간이 있어야 작동할 수 있음 / 페이지가 이동이 되고 구동이 되어있을때 사용한다. 
    await page.evaluate(function (sigungu) {
        document.querySelector(`#continents > li.${sigungu} > a`).click()
    }, sigungu)
}

const alertClose = async function () {
    await page.on('dialog', async function (dialog) { //page. 은 이름이 정해져있음 (이름이 아님), on은 이벤트 함수로 있을시에 작동하고 없으면 작동 안함
        await dialog.accept() //창이 아니라 alert이니까 그냥 accept만 하면 됨 
    })
}

const getPageLength = async function () {
    await page.waitForSelector(pageSelector)

    pageLength = await page.evaluate(function (pageSelector) {
        const result = document.querySelector(pageSelector).children.length
        return result
    },pageSelector)

} //다시보기

const getData = async function () {

    for (let i = 1; i < pageLength; i++) {

        await page.waitForSelector(pageSelector)
        //TODO

        await page.evaluate(function (i, pageSelector) { 

            document.querySelectorAll("#printZone > table:nth-child(2) > tbody tr") 

            document.querySelector(pageSelector).children[i].click()
        }, i, pageSelector)
    } 
    ////evaluate는 콘솔에 이 코드가 입력이 된다는 것, function안에 i를 넣고 뒤에 i를 넣는 공식은 외우기 / await page.evaluate(함수, i, pageSelector) 

}
export {
    launch,
    goto,
    alertClose,
    checkPopup,
    evalCode,
    evalCity,
    getPageLength,
    getData
}

